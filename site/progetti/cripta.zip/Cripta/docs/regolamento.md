# Cripta

Gli eroi scendono nella cripta e affrontano i mostri.

## Combattere

Un eroe tira tanti dadi quanto il suo attacco {spada}. Ogni 5 o 6 toglie un {cuore} al mostro. Il mostro risponde con il suo attacco, e ogni colpo che supera la difesa {scudo} dell'eroe è una ferita.
