# Guild

Each player leads a guild of adventurers. On your turn play an action card by paying its cost in coins, then do what its text says.

## Keywords

The words in bold red are keywords: they always mean the same thing.

