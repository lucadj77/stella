# Gilda

Ogni giocatore guida una gilda di avventurieri. Al tuo turno gioca una carta azione pagando il suo costo in monete, poi fai quello che dice il testo.

## Parole chiave

Le parole in grassetto rosso sono parole chiave: hanno sempre lo stesso significato.

