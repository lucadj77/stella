# Crypt

The heroes go down into the crypt and fight the monsters.

## Fighting

A hero rolls as many dice as their attack {sword}. Each 5 or 6 removes one {heart} from the monster. The monster strikes back with its attack, and each hit above the hero's defense {shield} is a wound.
